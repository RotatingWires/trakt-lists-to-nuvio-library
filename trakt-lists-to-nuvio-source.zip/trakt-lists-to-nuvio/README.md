# Trakt Lists → Nuvio Library v2

A dependency-free Python importer for personal Trakt lists from a Trakt account export ZIP.

## v2 fixes the blank-library problem

The first version could import membership correctly but the Trakt export itself only contains basic title/year/ID data. That meant imported Nuvio rows had blank poster, background, description, rating, and genres.

v2 fixes that by looking up each IMDb title in **Cinemeta** before writing to Nuvio. It fills the metadata Nuvio's library sync model supports:

- poster
- poster shape
- background
- title logo when Cinemeta supplies one
- description
- release info
- IMDb rating
- genres

It also repairs rows created by v1. **You do not need to delete the existing 118 items first.** Run v2 with the same Trakt export and it will match the existing items, fill their blank fields, and keep existing nonblank/customized values.

v2 also removes the `https://trakt.tv` value that v1 incorrectly placed in `addon_base_url` for matching imported entries.

## Your supplied export

- `shows`: 41 shows
- `movies`: 77 movies
- `good show episodes`: 7 episode entries
- 118 unique Nuvio movie/series titles after deduplication

Episode entries are converted to their parent series by default.

## Recommended repair command

Unzip this package into the same folder as your Trakt export, then run:

```bash
python3 trakt_lists_to_nuvio.py trakt-export-trafficjam.zip --all
```

The tool will first fetch artwork/details from Cinemeta, then ask for your Nuvio login, pull your existing library, save a backup, and show a repair summary such as:

```text
Current Nuvio library: 118 items
Trakt candidates:      118 unique titles
Existing enriched:     ...
Existing unchanged:    ...
New titles to add:     ...
Final library:         ...
```

Type `IMPORT` only after checking those counts.

## Preview without changing Nuvio

```bash
python3 trakt_lists_to_nuvio.py trakt-export-trafficjam.zip --all --dry-run
```

A v2 dry run **does contact Cinemeta for metadata**, but it does not log in to Nuvio or modify Nuvio.

For a completely offline parse only:

```bash
python3 trakt_lists_to_nuvio.py trakt-export-trafficjam.zip --all --dry-run --no-enrich
```

## What happens to existing Nuvio items?

The tool downloads your current Nuvio library and saves a JSON backup before any write. For entries from the selected Trakt lists it:

- fills metadata only when the existing field is blank;
- preserves nonblank existing metadata/custom edits;
- converts old fallback `tmdb:`/`trakt:` IDs to IMDb IDs when Cinemeta can resolve them;
- avoids creating a duplicate when it performs that ID conversion;
- removes the old v1 `https://trakt.tv` addon URL marker.

Other valid Nuvio library items are preserved.

## Other options

Import only selected lists:

```bash
python3 trakt_lists_to_nuvio.py trakt-export-trafficjam.zip --list movies --list shows
```

Skip episode/season entries instead of adding their parent series:

```bash
python3 trakt_lists_to_nuvio.py trakt-export-trafficjam.zip --all --episodes skip
```

Specify a Nuvio profile and skip the final confirmation:

```bash
python3 trakt_lists_to_nuvio.py trakt-export-trafficjam.zip --all --profile 1 --yes
```

You may use `NUVIO_EMAIL` and `NUVIO_PASSWORD` environment variables. The password is deliberately not accepted as a normal command-line argument.

## Metadata limitations

Cinemeta is used because Nuvio's own bundled Stremio documentation describes it as the primary metadata source for IMDb movie/series IDs and documents its `/meta/{movie|series}/{imdb}.json` endpoint.

Not every title necessarily has every field. In particular, a title-logo URL may remain blank if Cinemeta does not provide one. Posters/backgrounds/descriptions/ratings/genres are imported when present.

If Cinemeta returns no metadata at all for every selected title, v2 aborts before contacting Nuvio instead of re-writing sparse rows.

## Security and backups

No third-party Python packages are needed. Your Nuvio password is entered with hidden input and is not saved by the script.

Before a real write, the tool creates:

```text
nuvio-library-backup-profile-<id>-YYYYMMDD-HHMMSS.json
```

Keep that backup until you have verified the repaired library.

## Implementation references

- Nuvio: https://nuvio.tv/
- Official Nuvio Mobile: https://github.com/NuvioMedia/NuvioMobile
- Current Trakt library implementation: https://github.com/NuvioMedia/NuvioMobile/blob/cmp-rewrite/composeApp/src/commonMain/kotlin/com/nuvio/app/features/trakt/TraktLibraryRepository.kt
- Current library sync model: https://github.com/NuvioMedia/NuvioMobile/blob/cmp-rewrite/composeApp/src/commonMain/kotlin/com/nuvio/app/features/library/sync/SupabaseLibrarySyncAdapter.kt
- Nuvio-bundled Cinemeta/Stremio documentation: https://github.com/NuvioMedia/NuvioMobile/blob/cmp-rewrite/Docs/Stremio%20addons%20refer/advanced.md
